# Proffy Web

Plataforma que conecta alunos e professores. Este repositório contém o front-end em React.

## Como rodar o projeto localmente

Pré-requisitos: Node.js 20+ e npm.

```bash
# instalar as dependências
npm install

# subir o servidor de desenvolvimento (http://localhost:5173)
npm run dev

# gerar o build de produção
npm run build

# rodar o lint
npm run lint
```

## Rotas / telas implementadas

| Rota                              | Tela                                   | Arquivo                                   |
| --------------------------------- | -------------------------------------- | ----------------------------------------- |
| `/sign-in`                        | Login                                  | `src/pages/auth/sign-in.tsx`              |
| `/sign-up`                        | Cadastro                               | `src/pages/auth/sign-up.tsx`              |
| `/sign-up/finally-register`       | Cadastro concluído                     | `src/pages/auth/finally-register.tsx`     |
| `/`                               | Home                                   | `src/pages/app/home.tsx`                  |
| `/study`                          | Lista de professores                   | `src/pages/app/teacher-list.tsx`          |
| `/give-classes`                   | **Formulário "Dar aulas"**             | `src/pages/app/teacher-forms.tsx`         |
| `/give-classes/register-completed`| **Confirmação "Cadastro salvo!"**      | `src/pages/app/teacher-forms-completed.tsx` |
| `/profile`                        | **Perfil do professor "Meu perfil"**   | `src/pages/app/teacher-profile.tsx`       |

Fluxo: **Home → "Dar aula" → formulário → "Salvar cadastro" → confirmação → "Acessar lista" → Meu perfil**.

## Decisões técnicas

- **Stack mantida**: React 19 + TypeScript, Vite, Tailwind CSS v4, React Router v7, React Hook Form + Zod.
- **Zod é a única fonte de verdade da validação** (`src/schemas/teacher-schema.ts`). O `<form>` usa `noValidate` e as mensagens de erro vêm do schema. O perfil reaproveita o schema do formulário com `.extend()` (nome, sobrenome e e-mail).
- **Estado do formulário só no React Hook Form**: sem `useState` por campo. Os campos de "Sobre a aula" e "Horários disponíveis" são componentes que lêem o formulário via `FormProvider`/`useFormContext`, então são compartilhados entre o formulário e o perfil sem prop drilling.
- **Horários dinâmicos** com `useFieldArray`: é possível adicionar quantos forem necessários e excluir qualquer um, desde que sobre pelo menos um.
- **Máscara de WhatsApp** em `src/lib/masks.ts`, aplicada pelo `InputCustom` (prop `mask`) antes do React Hook Form ler o valor. Aceita celular `(99) 99999-9999` e fixo `(99) 9999-9999`.
- **Limite de 300 caracteres** na biografia: `maxLength` no textarea (conveniência) + `.max(300)` no Zod (regra).
- **Persistência**: como ainda não há API, o cadastro é salvo no `localStorage` (`src/lib/teacher-storage.ts`) e lido pela tela de perfil. Ao ler, os dados são revalidados com o schema. Trocar por uma API depois exige mexer apenas nesse arquivo.
- **Usuário logado fixo** em `src/data/current-user.ts` (não há autenticação ainda).
- **Componentização**: `PageHeader`, `FormCard`, `FormSection`, `FormFooter`, `FieldError`, `ClassDetailsFields`, `ScheduleFields`, além de `Button`, `Select`, `InputCustom`, `TextArea` e `Finally` (reaproveitado na confirmação). `Select`, `InputCustom` e `TextArea` agora exibem a própria mensagem de erro.
- **Botão "Salvar cadastro"** fica desabilitado enquanto o formulário for inválido (e, no perfil, enquanto não houver alterações).
