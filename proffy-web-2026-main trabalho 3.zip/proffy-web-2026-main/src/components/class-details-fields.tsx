import { useFormContext } from "react-hook-form"

import { InputCustom } from "./input-custom"
import { Select } from "./select"
import { FormSection } from "./form-section"
import { subjectOptions } from "../data/teacher-options"
import type { TeacherFormInput } from "../schemas/teacher-schema"

export function ClassDetailsFields() {
    const {
        register,
        formState: { errors },
    } = useFormContext<TeacherFormInput>()

    return (
        <FormSection title="Sobre a aula" className="mt-16">
            <div className="grid grid-cols-5 w-full gap-8">
                <div className="flex flex-col col-span-3">
                    <Select
                        name="subject"
                        label="Matéria"
                        labelColor="text-text-complement"
                        bgColor="bg-white-shape"
                        optionDefault="Selecione qual você quer ensinar"
                        options={subjectOptions}
                        register={register}
                        error={errors.subject}
                    />
                </div>

                <div className="flex flex-col col-span-2">
                    <InputCustom
                        name="cost"
                        label="Custo da sua hora por aula"
                        labelColor="text-text-complement"
                        bgColor="bg-white-shape"
                        startAdornment="R$"
                        placeholder="0,00"
                        type="number"
                        min="0.01"
                        step="0.01"
                        register={register}
                        error={errors.cost}
                    />
                </div>
            </div>
        </FormSection>
    )
}
