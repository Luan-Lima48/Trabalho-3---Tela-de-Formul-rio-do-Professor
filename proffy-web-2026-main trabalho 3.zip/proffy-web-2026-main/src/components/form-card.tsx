import type { ReactNode } from "react"

type FormCardProps = {
    children: ReactNode
}

export function FormCard({ children }: FormCardProps) {
    return (
        <main className="flex flex-col w-full max-w-4xl my-auto bg-white border border-gray-lines-in-white rounded-lg -mt-[3.2rem] overflow-hidden pt-16 mb-16 shadow-sm">
            {children}
        </main>
    )
}
