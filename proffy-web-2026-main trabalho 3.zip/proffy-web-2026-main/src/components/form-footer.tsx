import attentionIcon from "../assets/attention.svg"
import { Button } from "./button"

type FormFooterProps = {
    disabled: boolean
}

export function FormFooter({ disabled }: FormFooterProps) {
    return (
        <div className="flex w-full px-16 mt-10 py-8 bg-white-shape items-center justify-between border-t border-gray-lines-in-white">
            <div className="flex gap-4 items-center">
                <img src={attentionIcon} alt="Aviso importante" className="w-8 h-8" />
                <p className="font-poppins-regular text-xs text-purple">
                    Importante!<br />
                    <span className="text-text-complement">Preencha todos os dados corretamente.</span>
                </p>
            </div>

            <Button
                type="submit"
                title="Salvar cadastro"
                disabled={disabled}
                className="w-auto mt-0 py-4 px-10"
            />
        </div>
    )
}
