import type { ReactNode } from "react"

type FormSectionProps = {
    title: string
    action?: ReactNode
    className?: string
    children: ReactNode
}

export function FormSection({ title, action, className = "", children }: FormSectionProps) {
    return (
        <fieldset className={`flex flex-col items-center mx-16 ${className}`}>
            <legend className="flex w-full items-center justify-between pb-6 font-archivo-semibold text-2xl text-text-title border-b border-gray-lines-in-white">
                {title}
                {action}
            </legend>
            <div className="flex flex-col w-full mt-8">{children}</div>
        </fieldset>
    )
}
