import { useFieldArray, useFormContext } from "react-hook-form"

import { InputCustom } from "./input-custom"
import { Select } from "./select"
import { FormSection } from "./form-section"
import { emptyScheduleItem, weekDayOptions } from "../data/teacher-options"
import type { TeacherFormInput } from "../schemas/teacher-schema"

export function ScheduleFields() {
    const {
        control,
        register,
        formState: { errors },
    } = useFormContext<TeacherFormInput>()

    const { fields: scheduleItems, append, remove } = useFieldArray({
        control,
        name: "schedule",
    })

    // Sempre precisa sobrar pelo menos um horário.
    const canRemoveScheduleItem = scheduleItems.length > 1

    function addNewScheduleItem() {
        append(emptyScheduleItem)
    }

    return (
        <FormSection
            title="Horários disponíveis"
            className="mt-16"
            action={
                <button
                    type="button"
                    className="text-base text-purple cursor-pointer hover:text-dark-purple transition"
                    onClick={addNewScheduleItem}
                >
                    + Novo horário
                </button>
            }
        >
            {scheduleItems.map((scheduleItem, index) => (
                <div key={scheduleItem.id} className="w-full">
                    <div className="grid grid-cols-4 w-full gap-8 mb-4">
                        <div className="flex flex-col col-span-2">
                            <Select
                                name={`schedule.${index}.week_day`}
                                label="Dia da semana"
                                labelColor="text-text-complement"
                                bgColor="bg-white-shape"
                                optionDefault="Selecione o dia"
                                options={weekDayOptions}
                                register={register}
                                error={errors.schedule?.[index]?.week_day}
                            />
                        </div>

                        <div className="flex flex-col col-span-1">
                            <InputCustom
                                name={`schedule.${index}.from`}
                                label="Das"
                                labelColor="text-text-complement"
                                bgColor="bg-white-shape"
                                type="time"
                                register={register}
                                error={errors.schedule?.[index]?.from}
                            />
                        </div>

                        <div className="flex flex-col col-span-1">
                            <InputCustom
                                name={`schedule.${index}.to`}
                                label="Até"
                                labelColor="text-text-complement"
                                bgColor="bg-white-shape"
                                type="time"
                                register={register}
                                error={errors.schedule?.[index]?.to}
                            />
                        </div>
                    </div>

                    <div className="flex items-center w-full gap-8 mt-8 mb-8">
                        {canRemoveScheduleItem ? (
                            <>
                                <span className="flex-1 border-t border-gray-lines-in-white" />
                                <button
                                    type="button"
                                    className="font-archivo-semibold text-base text-red-500 cursor-pointer hover:text-red-600 transition"
                                    onClick={() => remove(index)}
                                >
                                    Excluir horário
                                </button>
                                <span className="flex-1 border-t border-gray-lines-in-white" />
                            </>
                        ) : (
                            <span className="w-full border-t border-gray-lines-in-white" />
                        )}
                    </div>
                </div>
            ))}
        </FormSection>
    )
}
