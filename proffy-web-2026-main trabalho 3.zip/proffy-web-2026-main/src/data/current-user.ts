export const currentUser = {
    name: "Luan",
    lastName: "Lima",
    email: "luan.lima@email.com",
    avatarUrl: "https://avatars.githubusercontent.com/u/287266514?s=400&u=f9b5aee174ecdf229ed27f9d1936087ff46f7c50&v=4",
}

export const currentUserFullName = `${currentUser.name} ${currentUser.lastName}`
