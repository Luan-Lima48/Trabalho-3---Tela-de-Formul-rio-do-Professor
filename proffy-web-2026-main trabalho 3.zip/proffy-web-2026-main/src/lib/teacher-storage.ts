import { teacherProfileSchema, type TeacherProfileData } from "../schemas/teacher-schema"

const STORAGE_KEY = "@proffy:teacher-profile"

export function saveTeacherProfile(profile: TeacherProfileData): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile))
}

export function loadTeacherProfile(): TeacherProfileData | null {
    const storedProfile = localStorage.getItem(STORAGE_KEY)
    if (!storedProfile) return null

    try {
        const result = teacherProfileSchema.safeParse(JSON.parse(storedProfile))
        return result.success ? result.data : null
    } catch {
        return null
    }
}
