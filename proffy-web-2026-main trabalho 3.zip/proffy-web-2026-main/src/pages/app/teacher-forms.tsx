import { useNavigate } from "react-router"
import { FormProvider, useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"

import rocketIcon from "../../assets/rocket.svg"
import { PageHeader } from "../../components/page-header"
import { FormCard } from "../../components/form-card"
import { FormSection } from "../../components/form-section"
import { FormFooter } from "../../components/form-footer"
import { ClassDetailsFields } from "../../components/class-details-fields"
import { ScheduleFields } from "../../components/schedule-fields"
import { InputCustom } from "../../components/input-custom"
import { TextArea } from "../../components/text-area"
import { currentUser, currentUserFullName } from "../../data/current-user"
import { emptyScheduleItem } from "../../data/teacher-options"
import { maskPhone } from "../../lib/masks"
import { saveTeacherProfile } from "../../lib/teacher-storage"
import {
    teacherFormSchema,
    type TeacherFormData,
    type TeacherFormInput,
} from "../../schemas/teacher-schema"

export function TeacherForms() {
    const navigate = useNavigate()

    const form = useForm<TeacherFormInput, unknown, TeacherFormData>({
        resolver: zodResolver(teacherFormSchema),
        mode: "onChange",
        defaultValues: {
            schedule: [emptyScheduleItem],
        },
    })

    const {
        handleSubmit,
        register,
        formState: { errors, isValid, isSubmitting },
    } = form

    function handleCreateClass(data: TeacherFormData) {
        saveTeacherProfile({
            name: currentUser.name,
            lastName: currentUser.lastName,
            email: currentUser.email,
            ...data,
        })
        navigate("/give-classes/register-completed")
    }

    return (
        <div className="w-full min-h-screen items-center flex flex-col bg-background antialiased overflow-x-hidden">
            <PageHeader title="Dar aulas" />

            <div className="w-full flex flex-col items-center bg-purple h-[352px]">
                <div className="flex w-full max-w-4xl mt-16 px-4">
                    <h1 className="font-archivo-bold text-4xl text-white">
                        Que incrível que você<br />quer dar aulas.
                    </h1>
                </div>

                <div className="flex w-full max-w-4xl justify-between items-center mt-6 px-4">
                    <p className="font-poppins-regular text-base text-text-purple-base">
                        O primeiro passo, é preencher esse<br />formulário de inscrição.
                    </p>

                    <div className="flex flex-row gap-4 items-center">
                        <img src={rocketIcon} alt="" className="w-8 h-8" />
                        <span className="font-poppins-regular text-sm text-text-purple-base">
                            Prepare-se!<br />vai ser o máximo.
                        </span>
                    </div>
                </div>
            </div>

            <FormCard>
                <FormProvider {...form}>
                    <form onSubmit={handleSubmit(handleCreateClass)} noValidate>
                        <FormSection title="Seus dados">
                            <div className="flex w-full justify-between items-center">
                                <div className="flex items-center">
                                    <img
                                        className="w-20 h-20 rounded-full object-cover"
                                        src={currentUser.avatarUrl}
                                        alt={currentUserFullName}
                                    />
                                    <strong className="font-archivo-semibold text-2xl text-text-title block ms-6">
                                        {currentUserFullName}
                                    </strong>
                                </div>

                                <div className="flex flex-col w-72">
                                    <InputCustom
                                        name="whatsapp"
                                        label="Whatsapp"
                                        placeholder="( ) _____-____"
                                        labelColor="text-text-complement"
                                        bgColor="bg-white-shape"
                                        mask={maskPhone}
                                        maxLength={15}
                                        inputMode="tel"
                                        register={register}
                                        error={errors.whatsapp}
                                    />
                                </div>
                            </div>

                            <div className="flex flex-col w-full mt-8">
                                <TextArea
                                    name="biography"
                                    label="Biografia"
                                    spanLabel="(Máximo 300 caracteres)"
                                    labelColor="text-text-complement"
                                    bgColor="bg-white-shape"
                                    maxLength={300}
                                    register={register}
                                    error={errors.biography}
                                />
                            </div>
                        </FormSection>

                        <ClassDetailsFields />
                        <ScheduleFields />

                        <FormFooter disabled={!isValid || isSubmitting} />
                    </form>
                </FormProvider>
            </FormCard>
        </div>
    )
}
