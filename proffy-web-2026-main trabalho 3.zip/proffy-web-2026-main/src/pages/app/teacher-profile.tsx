import { useMemo } from "react"
import { FormProvider, useForm, useWatch } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Camera } from "lucide-react"
import { toast } from "sonner"

import { PageHeader } from "../../components/page-header"
import { FormCard } from "../../components/form-card"
import { FormSection } from "../../components/form-section"
import { FormFooter } from "../../components/form-footer"
import { ClassDetailsFields } from "../../components/class-details-fields"
import { ScheduleFields } from "../../components/schedule-fields"
import { InputCustom } from "../../components/input-custom"
import { TextArea } from "../../components/text-area"
import { currentUser } from "../../data/current-user"
import { emptyScheduleItem } from "../../data/teacher-options"
import { maskPhone } from "../../lib/masks"
import { loadTeacherProfile, saveTeacherProfile } from "../../lib/teacher-storage"
import {
    teacherProfileSchema,
    type TeacherProfileData,
    type TeacherProfileInput,
} from "../../schemas/teacher-schema"

function toFormValues(profile: TeacherProfileData): TeacherProfileInput {
    return { ...profile, cost: profile.cost.toFixed(2) }
}

function getInitialValues(): TeacherProfileInput {
    const savedProfile = loadTeacherProfile()
    if (savedProfile) return toFormValues(savedProfile)

    return {
        name: currentUser.name,
        lastName: currentUser.lastName,
        email: currentUser.email,
        whatsapp: "",
        biography: "",
        subject: "",
        cost: "",
        schedule: [emptyScheduleItem],
    }
}

export function TeacherProfile() {
    const initialValues = useMemo(getInitialValues, [])

    const form = useForm<TeacherProfileInput, unknown, TeacherProfileData>({
        resolver: zodResolver(teacherProfileSchema),
        mode: "onChange",
        defaultValues: initialValues,
    })

    const {
        control,
        handleSubmit,
        register,
        reset,
        formState: { errors, isValid, isDirty, isSubmitting },
    } = form

    const [name, lastName, subject] = useWatch({
        control,
        name: ["name", "lastName", "subject"],
    })

    function handleSaveProfile(data: TeacherProfileData) {
        saveTeacherProfile(data)
        reset(toFormValues(data))
        toast.success("Cadastro atualizado com sucesso!")
    }

    return (
        <div className="w-full min-h-screen items-center flex flex-col bg-background antialiased overflow-x-hidden">
            <PageHeader title="Meu perfil" />

            <div className="w-full flex flex-col items-center bg-purple h-[352px]">
                <div className="relative mt-8">
                    <img
                        src={currentUser.avatarUrl}
                        alt={`${name} ${lastName}`}
                        className="w-36 h-36 rounded-full object-cover"
                    />
                    <span
                        aria-hidden="true"
                        className="absolute bottom-1 right-1 flex w-11 h-11 items-center justify-center rounded-full bg-green text-white"
                    >
                        <Camera size={20} />
                    </span>
                </div>

                <strong className="font-archivo-bold text-4xl text-white mt-5">
                    {name} {lastName}
                </strong>
                <span className="font-poppins-regular text-base text-text-purple-base mt-2">
                    {subject}
                </span>
            </div>

            <FormCard>
                <FormProvider {...form}>
                    <form onSubmit={handleSubmit(handleSaveProfile)} noValidate>
                        <FormSection title="Seus dados">
                            <div className="grid grid-cols-2 w-full gap-8">
                                <div className="flex flex-col">
                                    <InputCustom
                                        name="name"
                                        label="Nome"
                                        labelColor="text-text-complement"
                                        bgColor="bg-white-shape"
                                        register={register}
                                        error={errors.name}
                                    />
                                </div>
                                <div className="flex flex-col">
                                    <InputCustom
                                        name="lastName"
                                        label="Sobrenome"
                                        labelColor="text-text-complement"
                                        bgColor="bg-white-shape"
                                        register={register}
                                        error={errors.lastName}
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 w-full gap-8 mt-8">
                                <div className="flex flex-col">
                                    <InputCustom
                                        name="email"
                                        label="E-mail"
                                        type="email"
                                        labelColor="text-text-complement"
                                        bgColor="bg-white-shape"
                                        register={register}
                                        error={errors.email}
                                    />
                                </div>
                                <div className="flex flex-col">
                                    <InputCustom
                                        name="whatsapp"
                                        label="Whatsapp"
                                        placeholder="( ) _____-____"
                                        labelColor="text-text-complement"
                                        bgColor="bg-white-shape"
                                        mask={maskPhone}
                                        maxLength={15}
                                        inputMode="tel"
                                        register={register}
                                        error={errors.whatsapp}
                                    />
                                </div>
                            </div>

                            <div className="flex flex-col w-full mt-8">
                                <TextArea
                                    name="biography"
                                    label="Biografia"
                                    spanLabel="(Máximo 300 caracteres)"
                                    labelColor="text-text-complement"
                                    bgColor="bg-white-shape"
                                    maxLength={300}
                                    register={register}
                                    error={errors.biography}
                                />
                            </div>
                        </FormSection>

                        <ClassDetailsFields />
                        <ScheduleFields />

                        <FormFooter disabled={!isValid || !isDirty || isSubmitting} />
                    </form>
                </FormProvider>
            </FormCard>
        </div>
    )
}
